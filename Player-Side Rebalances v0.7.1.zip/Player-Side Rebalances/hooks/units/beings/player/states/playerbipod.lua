function PlayerBipod:get_movement_state()
	return "bipod"
end