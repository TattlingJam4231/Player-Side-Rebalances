function PlayerTweakData:_set_singleplayer()
	self.damage.REGENERATE_TIME = 3
end