if not sentry_cost then
	SentryGunBase.DEPLOYEMENT_COST = {
		0.75,
		0.8,
		0.85
	}
	SentryGunBase.MIN_DEPLOYEMENT_COST = 0.15
	sentry_cost = true
end