Hooks:PostHook(UpgradesTweakData, "_init_pd2_values", "Oryo UpgradesTweakData init", function(self)
	self.sentry_gun_base_ammo = 400
end)